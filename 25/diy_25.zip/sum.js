function sum(num1, num2) {
    // Add the two numbers together
    let sum = num1 + num2;
  
    // Return the sum
    return sum;
  }
  
  
  