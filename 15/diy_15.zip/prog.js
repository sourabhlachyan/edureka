
var number1 = 5;
var number2 = 10;
var number3 = 15;
var number4 = 20;
var string = "helloworld";
var booleanValue = true;


console.log(number1,number2,number3,number4);
console.log(string);
console.log(booleanValue);
